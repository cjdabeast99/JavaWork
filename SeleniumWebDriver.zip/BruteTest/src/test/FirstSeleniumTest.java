package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.*;

public class FirstSeleniumTest {
	
	
	public static void main(String[] args) {
			
		Scanner sc= new Scanner(System.in); 
		
		System.out.print("Enter a website: ");  
		String input= sc.nextLine(); 
				 
		ChromeOptions options = new ChromeOptions();
		options.setBinary("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
		System.setProperty("webdriver.chrome.driver","G:\\webdrivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(options);
		
		driver.get("https://" + input);
		
		System.out.print("Type Q to quit: ");  
		String quitInput= sc.nextLine(); 
		if(quitInput == "Q") {
			driver.quit();
		}else {
			System.out.print("Type Q to quit: ");  
			quitInput= sc.nextLine();
		}
		
	}
	
}
