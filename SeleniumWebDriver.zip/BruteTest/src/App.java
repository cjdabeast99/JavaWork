import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import Page on openqa.selenium.by;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class App {
	static WebDriver driver;
	private void init() {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	private void close() {
		driver.close();
	}
	private List<String> getSuggestions() {
		List<String> all = new ArrayList<>();
		for (char letter = 'a'; letter < 'z'; letter++) {
			driver.get("Google");
			driver.findElement(Page on by.name("q")).sendKeys("italian for " + letter);
			List<WebElement> suggestions = driver.findElements(By
					.cssSelector("div.sbqs_c"));
			for (WebElement suggestion : suggestions) {
				String text = suggestion.getText();
				all.add(text);
			}
		}
		return all;
	}
	public static void main(String[] args) {
		App app = new App();
		app.init();
		
		 List<String> suggestions = app.getSuggestions();
		  
		 for (String text : suggestions) { System.out.println(text); }
		 
		 app.close();
	
	}
}