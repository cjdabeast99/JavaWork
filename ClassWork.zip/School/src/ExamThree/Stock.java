package ExamThree;
import java.util.*;
import java.io.*;

public class Stock {
	public static void main (String[] args)throws FileNotFoundException {
		ArrayList<Integer> data = readFromFile();
		int maxValue = largestIncrease(data);
		int startDay = findStartDay(data);
		int endDay = startDay + 1;
		printOutput(maxValue, startDay, endDay);
		}// end main
	
	public static ArrayList<Integer> readFromFile () throws FileNotFoundException
	{// Reads input from a file named "stock.txt" that contains at least 2 values
	 // and returns an array list of Integer

		File f = new File ("stock.txt");
		Scanner fileIn = new Scanner (f);
		// You should complete the rest of the code for the method below
		ArrayList<Integer> openStock = new ArrayList<Integer>();
		while (fileIn.hasNext()){
		    if(fileIn.hasNextInt()){
		    	openStock.add(fileIn.nextInt());
		    }
		}
		return openStock;
	}
	
	public static int largestIncrease (ArrayList<Integer> prices)
	{// Returns the value of the largest increase between consecutive days 
		int largestInc = 0;
		for(int i = 0; i <= prices.size() - 1; i++) {
			if (i < prices.size() -1) {
				int valDifference = prices.get(i + 1) - prices.get(i);
				if (valDifference > largestInc) {
					largestInc = valDifference;
				}
			}
		}
		return largestInc;
	}// end largestIncrease

	public static int findStartDay (ArrayList<Integer> prices)
	{// Returns the starting day of the largest increase between consecutive days
		int startDay = 0;
		int largestInc = 0;
		for(int i = 0; i <= prices.size() - 1; i++) {
			if (i < prices.size() -1) {
				int valDifference = prices.get(i + 1) - prices.get(i);
				if (valDifference > largestInc) {
					largestInc = valDifference;
					startDay = i + 1;
				}
			}
		}
		return startDay;
	}// end findStartDay
	
	public static void printOutput (int max, int start, int end)
	{// Prints the specified output

		System.out.println("Largest increase of " + max);
	
		//You should complete the next println statement that has been started below
	
		System.out.println("occurred between day #" + start + " and day #" + end + ".");
	}

}
