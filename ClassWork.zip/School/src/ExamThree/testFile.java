package ExamThree;
import java.util.*;

public class testFile {
	
	
	public static void main(String[] args) {
		ArrayList<Integer> data = new ArrayList<Integer>(); 
		
		data.add(4);
		data.add(3);
		data.add(-2);
		data.add(9);
		
		System.out.println("Original: " + data);
		System.out.println("Reverse: " + reverse(data));

	}
	
	public static ArrayList<Integer> reverse (ArrayList<Integer> data)
	{
		ArrayList<Integer> reverseArray = new ArrayList<Integer>(); 
	     for (int i = data.size() - 1; i >= 0; i--) { 
	     		reverseArray.add(data.get(i)); 
	     }
	     return reverseArray; 
	}
}
