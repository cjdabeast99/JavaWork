package ExamThree;

import java.util.Scanner;

public class BankAccount {
	private static String accountID;
	private static double balance;
	private static String dateOpened;
	
	public static void main(String[] args) {
		accountID = "ABC123";
		balance = 200;
		dateOpened = "09/24/1999";
		constructor(accountID, balance, dateOpened);
	}
	
	public static void constructor(String ID, double accountBalance, String accountOpened) {
		System.out.println("Account: " + ID);
		System.out.println("Balance: " + accountBalance);
		Scanner stdin = new Scanner(System.in);
		System.out.print("Please enter \"deposit\", \"withdraw\", or \"getDateOpened\" depending on what you want to access: ");
		String requestData = stdin.next();
		System.out.println();
		
		if (requestData.equals("deposit")) {
			System.out.print("Enter how much you would like to deposit: ");
			double addDeposit = stdin.nextDouble();
			System.out.print("Your balance is now: " + deposit(addDeposit));
		}else if(requestData.equals("withdraw")) {
			System.out.print("Enter how much you would like to withdraw: ");
			double withdrawAmount = stdin.nextDouble();
			if (withdraw(withdrawAmount) == true) {
				System.out.print("Your balance is now: " + balance);
			}else {
				System.out.print("ERROR: Your withdraw amount exceeds your balance!");
			}
		}else if(requestData.equals("getDateOpened")) {
			System.out.print(getDateOpened());
		}else {
			System.out.println("ERROR: " + requestData + " is not a command!");
		}
	}
	
	public static double deposit(double inputVar) {
		double addedInput = inputVar + balance;
		return addedInput;
	}
	
	public static boolean withdraw(double amtWithdraw) {
		if (amtWithdraw > balance) {
			return false;
		}else {
			balance = balance - amtWithdraw;
			return true;
		}
	}
	
	public static String getDateOpened() {
		return dateOpened;
	}
}
