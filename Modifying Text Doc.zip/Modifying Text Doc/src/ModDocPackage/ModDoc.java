package ModDocPackage;
import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ModDoc {
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		Scanner sc= new Scanner(System.in); 
		
		System.out.print("Enter a a command (\"view\", \"update\", \"reset\", \"quit\"): ");  
		String input= sc.nextLine(); 
		if(input.equals("update")) {
			System.out.print("enter the number you want to set the value to: ");  
			String update= sc.nextLine();
			Update(update);
		}else if (input.equals("view")) {
			View("accountinfo.txt");
		}else if (input.equals("reset")) {
			Reset();
		}else if (input.equals("quit")){
			return;
		}else {
			System.out.print(input + " is an invalid command!\n\n");  
			main(args);
		}
		
	}
	
  public static void Update(String update) {
	    try {
	    	FileReader fr = new FileReader("accountinfo.txt");
		    BufferedReader br = new BufferedReader(fr);
		    String buffer = br.readLine();
	        String[] values = buffer.split("/", 3);
	    	FileWriter myWriter = new FileWriter("accountinfo.txt");
	    	String fileString = (values[0] + "/" + update + "/" + values[2]);
	      	myWriter.write(fileString);
	      	myWriter.close();
	      	System.out.println("Successfully updated number in the file.\n\n");
		    br.close();
		    fr.close();
		    main(null);
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
  }
  
  public static void View(String string) throws FileNotFoundException, IOException {
	    FileReader fr = new FileReader(string);
	    BufferedReader br = new BufferedReader(fr);
	    String buffer = br.readLine();
	    String[] values = buffer.split("/", 3);
        System.out.println("Name: " + values[0] + "\nAmount: " + values[1] + "\nDate Created: " + values[2] + "\n\n");
	    br.close();
	    fr.close();
	    main(null);
	}
  
  public static void Reset() {
	    try {
	    	FileWriter myWriter = new FileWriter("accountinfo.txt");
	      	myWriter.write("CJ Garnett/500/09-24-2021");
	      	myWriter.close();
	      	System.out.println("Successfully reset the file.");
	      	main(null);
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
}
  
}